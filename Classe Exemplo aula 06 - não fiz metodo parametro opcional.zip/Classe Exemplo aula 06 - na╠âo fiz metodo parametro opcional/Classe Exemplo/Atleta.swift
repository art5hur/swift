//
//  Atleta.swift
//  Classe Exemplo
//
//  Created by Usuário Convidado on 06/03/25.
//

import Foundation

class Atleta: AlimentoSolido, AlimentoLiquido{
    var nome:String
    var idade:Int
    var sobrenome:String
    
    var nomeCompleto:String{
        get{
            nome + " " + sobrenome
        }
    }
    
    //Mêtodo com parâmetro opcional
    func inscreverNaCompeticao(modalidade:String, cidade:String?=nil)->String{
        if cidade == nil {
            return "Atleta \(nome) inscrito na competição: \(modalidade)"
        }else{
            return "Atleta \(nome) inscrito na competição: \(modalidade) em: \(cidade!) "
        }
    }
    
    func beberIsotonico() {
        print("Atleta \(self.nome) vai beber Gatorade")
    }
    
    func comerCarboidrato() {
        print("Atleta \(self.nome) vai comer batata doce")
    }
    
    init(){
        self.nome = ""
        self.idade = 0
        self.sobrenome = ""
    }
    
    init(nome:String, idade:Int, sobrenome:String){
        self.nome = nome
        self.idade = idade
        self.sobrenome = sobrenome
    }
    
    deinit{
        print("\(nome) está sendo desinicializado")
    }
    //método de instância sem retorno (Void) com parâmetros
    func calcularIMC(peso:Float, altura:Float){
        let imc = peso / (altura * altura)
        let formatado = String(format: "%0.2f", imc)
        print("Atleta \(self.nome) tem IMC de\(formatado)")
    }
    //método de instância com retorno (function) também com parâmetros
    func calcularIMC_2(peso:Float, altura:Float)->Float{
        return peso / pow(altura,2)
    }
    //método de instância sem parâmetro com retorno sem parâmetros
    func exibirAtleta()->String{
        return "O atleta é \(self.nome)"
    }
    //método de classe (Mesmo que o estático do Java)
    class func alertar()->String{
        return "Me preparando para a competição que irá iniciar em breve"
    }
    //Exemplo de Overloads (Quando o método tem o mesmo nome e parâmetros
    //ou saídas diferentes.
    class func alertar(tempoEmMinutos:Int)->String{
        return "Me preparando para a competição que irá iniciar em \(tempoEmMinutos) minutos"
    }
}
