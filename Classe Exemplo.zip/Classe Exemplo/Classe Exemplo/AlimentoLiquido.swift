//
//  AlimentoLiquido.swift
//  Classe Exemplo
//
//  Created by Usuário Convidado on 13/03/25.
//

import Foundation

protocol AlimentoLiquido{
    func beberIsotonico()
}
