//
//  Atleta.swift
//  Classe Exemplo
//
//  Created by Usuário Convidado on 06/03/25.
//

import Foundation

class Atleta: AlimentoSolido, AlimentoLiquido{
    var nome:String
    var idade:Int
    var sobrenome:String
    
    var nomeCompleto:String{
        get{
            nome + " " + sobrenome
        }
    }
    
    func beberIsotonico(){
        print("Atleta \(self.nome) vai beber Gatorade")
    }
    
    func comerCarboidrato(){
        print("Atleta \(self.nome) vai comer batata doce")
    }
    
    init(){
        self.nome = ""
        self.idade = 0
        self.sobrenome = ""
    }
    
    init(nome:String, idade:Int, sobrenome:String){
        self.nome = nome
        self.idade = idade
        self.sobrenome = sobrenome
    }
    
    deinit{
        print("\(nome) está sendo desinicializado")
    }
    //método de instância sem retorno (Void)
    func calcularIMC(peso:Float, altura:Float){
        let imc = peso / (altura * altura)
        let formatado = String(format: "%0.2f", imc)
        print("Atleta \(self.nome) tem IMC de \(formatado)")
    }
    //Método de instância com retorno(function) também com parâmetros
    func calcularIMC_2(peso:Float, altura:Float)->Float{
        return peso / pow(altura, 2)
    }
    //Método de instância sem parâmetros com retorno
    func exibirAtleta()->String{
        return "O atleta é \(self.nome)"
    }
    //Método de classe (Mesmo que o estático do Java)
    class func alertar()->String{
        return "Me preparando para a competição que irá iniciar em breve"
    }
    //Exemplo de Overloads (Quando o método tem o mesmo nome e parâmetros
    //ou saídas diferentes.
    class func exibirAtleta(tempoEmMinutos:Int)->String{
        return "Me preparando para a competição que irá iniciar em \(tempoEmMinutos) minutos"
    }
    
}
