//
//  Paratleta.swift
//  Classe Exemplo
//
//  Created by Usuário Convidado on 13/03/25.
//

import Cocoa

class Paratleta: Atleta {
    //acima depois dos dois pontos é a herança
    var deficiencia:String
    
    //sobrecarga quando um método da classe pai (Override)
    override init() {
        self.deficiencia = ""
        super.init() //chamando o init da classe pai
    }
    //outro exemplo de override, ou seja, um método que está na classe pai
    override func exibirAtleta() -> String {
        return super.exibirAtleta() + " deficiência relatada é \(self.deficiencia)"
    }
    
}
