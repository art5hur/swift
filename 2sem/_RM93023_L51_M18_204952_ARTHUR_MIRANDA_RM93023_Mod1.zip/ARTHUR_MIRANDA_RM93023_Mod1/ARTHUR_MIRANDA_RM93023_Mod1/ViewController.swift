//
//  ViewController.swift
//  ARTHUR_MIRANDA_RM93023_Mod1
//
//  Created by Usuário Convidado on 28/08/25.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var lblFrase: UILabel!
    var textodoLabel:String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        lblFrase.text = textodoLabel
        // Do any additional setup after loading the view.
    }


}

