//
//  ViewController.swift
//  ARTHUR_MIRANDA_RM93023_Mod4
//
//  Created by Usuário Convidado on 02/10/25.
//

import UIKit

var naves:Naves!=nil

class ViewController: UIViewController {

    @IBOutlet weak var numTxt: UITextField!
    @IBOutlet weak var lblNome: UILabel!
    
    @IBOutlet weak var lblModelo: UILabel!
    @IBOutlet weak var lblFabricante: UILabel!
    @IBOutlet weak var lblCusto: UILabel!
    @IBOutlet weak var lblPassageiros: UILabel!
    @IBOutlet weak var lblTamanho: UILabel!
    

    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    func loadNaves(){
        //let campo = numTxt.text
        
        
        let jsonUrlString = "https://swapi.dev/api/starships/\(numTxt.text!)"
        let url = URL(string: jsonUrlString)
        
        URLSession.shared.dataTask(with: url!) { data, response, error in
            guard let data = data else {return}

            do{
                naves = try JSONDecoder().decode(Naves.self, from: data)
                //print(naves.name)
                DispatchQueue.main.sync {
                    self.lblNome.text = naves.name
                    self.lblModelo.text = naves.model
                    self.lblFabricante.text = naves.manufacturer
                    self.lblCusto.text = naves.cost_in_credits
                    self.lblPassageiros.text = naves.passengers
                    self.lblTamanho.text = naves.length
                    
                }
            }catch let jsonError{
                print("Error serialization Json", jsonError)
            }
        }
        .resume()
    }

    @IBAction func exibir(_ sender: Any) {
        loadNaves()
    }
    
    

}

