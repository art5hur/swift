//
//  Naves.swift
//  ARTHUR_MIRANDA_RM93023_Mod4
//
//  Created by Usuário Convidado on 02/10/25.
//

import Foundation

struct Naves: Decodable{
    var name:String
    var model:String
    var manufacturer:String
    var cost_in_credits:String
    var passengers:String
    var length:String
    
}
